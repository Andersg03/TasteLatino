//
//  Final_24App.swift
//  Final 24
//
//  Created by David Perez on 9/28/24.
//

import SwiftUI

@main
struct Final_24App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
